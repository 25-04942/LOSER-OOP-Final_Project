package loser.android;

import android.app.Application;

import java.time.LocalDateTime;

import loser.app.AppSession;

/**
 * Lives as long as the app process. Holds the one AppSession (settings, pet, tracker,
 * weekly report) so every screen shows the same data, and the store that keeps it on the device.
 */
public class LoserApp extends Application {
    private AppSession session;
    private AppStore store;
    private boolean permissionPromptShown = false;

    @Override
    public void onCreate() {
        super.onCreate();
        store = new AppStore(this);
        session = new AppSession(getString(R.string.pet_name));
        store.load(session);                                    // settings, pet name, saved days, sent alerts
        session.rollOverIfNewDay(session.logicalDay(LocalDateTime.now()));   // follow the saved reset time
        session.setNotifier(new AndroidNotificationService(this, session.getSettings()));
        session.setDaySavedListener(report -> store.saveDays(report));        // keep each finished day
        AndroidNotificationService.createChannel(this);
        UsageCheckWorker.schedule(this);                        // background check every 15 minutes
    }

    public AppSession getSession() {
        return session;
    }

    public AppStore getStore() {
        return store;
    }

    /** True once the "allow usage access" dialog was shown, so no screen asks twice. */
    public boolean isPermissionPromptShown() {
        return permissionPromptShown;
    }

    public void setPermissionPromptShown(boolean shown) {
        this.permissionPromptShown = shown;
    }
}
