package loser.android;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.time.LocalTime;

import loser.app.AppSession;
import loser.exception.MissingPermissionException;

/**
 * Parent class of every screen that has the bottom navigation (inheritance).
 * It holds what the screens share: the session, the system-bar handling, the navigation
 * wiring and the "read the phone's usage" step. Each screen only adds its own content.
 */
public abstract class BaseScreenActivity extends AppCompatActivity {
    protected AppSession session;
    private PermissionHelper permissionHelper;

    /** Call after setContentView(). selectedTabId is R.id.tabPet, R.id.tabUsage, ... */
    protected void setUpChrome(int selectedTabId) {
        session = ((LoserApp) getApplication()).getSession();
        permissionHelper = new PermissionHelper(this);

        applySystemBarInsets();
        if (findViewById(R.id.bottomNav) != null && findViewById(R.id.bottomNav).getVisibility() != View.GONE) {
            setUpNavigation(selectedTabId);
        }
    }

    /** Keeps content out from under the status bar and gesture bar. */
    private void applySystemBarInsets() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);   // draw behind system bars
        View root = findViewById(R.id.root);
        View nav = findViewById(R.id.bottomNav);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.setAppearanceLightStatusBars(true);
        controller.setAppearanceLightNavigationBars(true);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            boolean hasNav = nav != null && nav.getVisibility() != View.GONE;
            v.setPadding(0, bars.top, 0, hasNav ? 0 : bars.bottom);
            if (hasNav) nav.setPadding(0, 0, 0, bars.bottom);   // the keyboard (ime) pushes the navigation up
            return insets;
        });
    }

    private void setUpNavigation(int selectedTabId) {
        int[] tabs = {R.id.tabPet, R.id.tabUsage, R.id.tabHistory, R.id.tabSettings};
        for (int id : tabs) {
            // setSelected() on the tab also switches its pill, icon color and label color.
            findViewById(id).setSelected(id == selectedTabId);
        }
        findViewById(R.id.tabPet).setOnClickListener(v -> goTo(MainActivity.class));
        findViewById(R.id.tabUsage).setOnClickListener(v -> goTo(UsageActivity.class));
        findViewById(R.id.tabHistory).setOnClickListener(v -> goTo(HistoryActivity.class));
        findViewById(R.id.tabSettings).setOnClickListener(v -> goTo(SettingsActivity.class));
    }

    /** Opens another screen, or does nothing if it is the current one. */
    protected void goTo(Class<?> screen) {
        if (getClass().equals(screen)) {
            return;
        }
        Intent intent = new Intent(this, screen);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(0, 0);   // tabs switch instantly
    }

    /** Placeholder until those screens are designed and built. */
    protected void comingSoon(int nameRes) {
        Toast.makeText(this, getString(R.string.coming_soon, getString(nameRes)), Toast.LENGTH_SHORT).show();
    }

    /**
     * Reads the phone's usage into the session (today, and any past days that are missing),
     * updates the pet and sends the alerts that are due.
     *
     * @return true if the usage-access permission is missing (nothing was read)
     */
    protected boolean syncUsage() {
        try {
            UsageRefresher.run(this);
            return false;
        } catch (MissingPermissionException e) {
            askForPermissionOnce();
            return true;
        }
    }

    /** Called with the time the user picked. */
    protected interface TimeChoice {
        void onChosen(LocalTime time);
    }

    /** Shows Android's time picker, starting at the given time. */
    protected void pickTime(LocalTime initial, TimeChoice choice) {
        new TimePickerDialog(this,
                (view, hour, minute) -> choice.onChosen(LocalTime.of(hour, minute)),
                initial.getHour(), initial.getMinute(), false).show();
    }

    /** The pet's current name, for texts. */
    protected String petName() {
        return session.getPet().getName();
    }

    /** True if the user already allowed "Usage access" for this app. */
    protected boolean hasUsageAccess() {
        return permissionHelper.hasUsageAccess();
    }

    /** Opens the system screen where "Usage access" is turned on for this app. */
    protected void openUsageAccessSettings() {
        permissionHelper.openUsageAccessSettings();
    }

    private void askForPermissionOnce() {
        LoserApp app = (LoserApp) getApplication();
        if (!app.isPermissionPromptShown()) {   // ask once per app run, not on every screen
            app.setPermissionPromptShown(true);
            showPermissionDialog();
        }
    }

    private void showPermissionDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.permission_title)
                .setMessage(getString(R.string.permission_message, session.getPet().getName()))
                .setPositiveButton(R.string.permission_open_settings,
                        (d, which) -> permissionHelper.openUsageAccessSettings())
                .setNegativeButton(R.string.permission_not_now, null)
                .show();
    }
}
