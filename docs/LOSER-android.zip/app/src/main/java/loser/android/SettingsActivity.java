package loser.android;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import java.time.LocalTime;

import loser.exception.InvalidSettingsException;
import loser.ui.DashboardPresenter;
import loser.ui.SettingsForm;
import loser.ui.SettingsModel;
import loser.ui.SettingsPresenter;

/**
 * "Limits & alerts" screen. SettingsPresenter (plain Java, unit tested) prepares the texts and
 * checks the input; this class only fills the views and saves the result.
 */
public class SettingsActivity extends BaseScreenActivity {
    private EditText etHours, etMinutes, etPetName, etLongSession, etTired, etSick, etDevastated;
    private TextView tvSubtitle, tvLimitNote, tvPetUpdatesDesc, tvResetTime, tvFormError;
    private LocalTime resetTime;
    private TextView tvLimitHint, tvNotificationStatus, tvPreviewCaption, tvPreviewTitle, tvPreviewBody;
    private SwitchCompat switchPetUpdates, switchWarnings;
    private boolean notificationsAllowed = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        etHours = findViewById(R.id.etHours);
        etMinutes = findViewById(R.id.etMinutes);
        etPetName = findViewById(R.id.etPetName);
        etLongSession = findViewById(R.id.etLongSession);
        etTired = findViewById(R.id.etTired);
        etSick = findViewById(R.id.etSick);
        etDevastated = findViewById(R.id.etDevastated);
        tvSubtitle = findViewById(R.id.tvSubtitle);
        tvLimitNote = findViewById(R.id.tvLimitNote);
        tvPetUpdatesDesc = findViewById(R.id.tvPetUpdatesDesc);
        tvResetTime = findViewById(R.id.tvResetTime);
        tvFormError = findViewById(R.id.tvFormError);
        tvLimitHint = findViewById(R.id.tvLimitHint);
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus);
        tvPreviewCaption = findViewById(R.id.tvPreviewCaption);
        tvPreviewTitle = findViewById(R.id.tvPreviewTitle);
        tvPreviewBody = findViewById(R.id.tvPreviewBody);
        switchPetUpdates = findViewById(R.id.switchPetUpdates);
        switchWarnings = findViewById(R.id.switchWarnings);

        setUpChrome(R.id.tabSettings);
        fillFromSettings();

        findViewById(R.id.tvBack).setOnClickListener(v -> goTo(MainActivity.class));
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        tvResetTime.setOnClickListener(v -> pickTime(resetTime, time -> {
            resetTime = time;
            tvResetTime.setText(DashboardPresenter.clockText(resetTime));
        }));
        findViewById(R.id.tvDeviceAccess).setOnClickListener(v -> goTo(ConnectActivity.class));
        tvNotificationStatus.setOnClickListener(v -> {
            if (!notificationsAllowed) openNotificationSettings();
        });

        // tapping anywhere on a box edits its number
        findViewById(R.id.boxHours).setOnClickListener(v -> focus(etHours));
        findViewById(R.id.boxMinutes).setOnClickListener(v -> focus(etMinutes));

        // the reminder preview follows the limit while typing
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { updatePreview(); }
        };
        etHours.addTextChangedListener(watcher);
        etMinutes.addTextChangedListener(watcher);

        // "3" becomes "03" when the user leaves the box, as in the design
        etHours.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) pad(etHours); });
        etMinutes.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) pad(etMinutes); });
        etMinutes.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                save();
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // the user may have changed the notification permission in the system settings
        notificationsAllowed = NotificationManagerCompat.from(this).areNotificationsEnabled();
        SettingsModel m = SettingsPresenter.present(session.getSettings(), session.getPet(), notificationsAllowed);
        tvNotificationStatus.setText(m.getNotificationStatus());
        tvNotificationStatus.setTextColor(ContextCompat.getColor(this,
                notificationsAllowed ? R.color.success_text : R.color.warn_text));
    }

    /** Puts the saved settings into the boxes and switches. */
    private void fillFromSettings() {
        SettingsModel m = SettingsPresenter.present(session.getSettings(), session.getPet(), notificationsAllowed);
        etHours.setText(m.getHoursText());
        etPetName.setText(m.getPetName());
        resetTime = session.getSettings().getResetTime();
        tvResetTime.setText(m.getResetTimeText());
        etLongSession.setText(m.getLongSessionText());
        etTired.setText(m.getTiredText());
        etSick.setText(m.getSickText());
        etDevastated.setText(m.getDevastatedText());
        tvSubtitle.setText(m.getSubtitle());
        tvLimitNote.setText(m.getLimitNote());
        tvPetUpdatesDesc.setText(m.getPetUpdatesDesc());
        tvFormError.setVisibility(View.GONE);
        etMinutes.setText(m.getMinutesText());
        tvLimitHint.setText(m.getLimitHint());
        switchPetUpdates.setChecked(m.isPetUpdatesOn());
        switchWarnings.setChecked(m.isWarningsOn());
        tvPreviewCaption.setText(m.getPreviewCaption());
        tvPreviewTitle.setText(m.getPreviewTitle());
        tvPreviewBody.setText(m.getPreviewBody());
    }

    private void updatePreview() {
        try {
            int limit = SettingsPresenter.parseLimit(etHours.getText().toString(), etMinutes.getText().toString());
            tvPreviewBody.setText(SettingsPresenter.previewBody(limit, petName()));
            showHintOk();
        } catch (InvalidSettingsException e) {
            // keep the last valid preview; the hint turns red so the user sees the allowed range
            tvLimitHint.setTextColor(ContextCompat.getColor(this, R.color.warn_text));
        }
    }

    private void showHintOk() {
        tvLimitHint.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
    }

    private void save() {
        SettingsForm form = SettingsForm.current(session.getSettings(), session.getPet())
                .withLimit(etHours.getText().toString(), etMinutes.getText().toString())
                .withPetName(etPetName.getText().toString())
                .withResetTime(resetTime)
                .withLongSession(etLongSession.getText().toString())
                .withLevels(etTired.getText().toString(), etSick.getText().toString(),
                        etDevastated.getText().toString())
                .withSwitches(switchPetUpdates.isChecked(), switchWarnings.isChecked());
        try {
            SettingsPresenter.applyAll(session.getSettings(), session.getPet(), form);   // checks everything, then saves
        } catch (InvalidSettingsException e) {
            tvFormError.setText(e.getMessage());
            tvFormError.setVisibility(View.VISIBLE);
            tvLimitHint.setText(SettingsPresenter.limitHint());
            return;   // nothing was changed
        }
        LoserApp app = (LoserApp) getApplication();
        app.getStore().saveSettings(session);
        if (syncUsage()) {                    // reads the usage again with the new limit, day start and levels
            session.refreshPet();             // no permission: still apply the new levels to the pet
            app.getStore().saveMonitor(session.getMonitor());
        }

        fillFromSettings();                  // shows e.g. "3" as "03"
        showHintOk();
        View focused = getCurrentFocus();
        if (focused != null) {
            focused.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        }
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
    }

    private void focus(EditText box) {
        box.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.showSoftInput(box, InputMethodManager.SHOW_IMPLICIT);
    }

    private void pad(EditText box) {
        String text = box.getText().toString().trim();
        if (text.length() == 1) box.setText("0" + text);
        else if (text.isEmpty()) box.setText("00");
    }

    private void openNotificationSettings() {
        Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(intent);
    }
}
