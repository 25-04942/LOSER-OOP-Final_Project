package loser.android;

import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import loser.ui.UsageModel;
import loser.ui.UsagePresenter;

/**
 * "Your screen time" screen. UsagePresenter (plain Java, unit tested) prepares every number
 * and text; this class reads the phone's usage and fills the views and the two lists.
 */
public class UsageActivity extends BaseScreenActivity {
    private static final int BAR_MAX = 1000;   // matches android:max in the layouts

    private TextView tvDate, tvTotal, tvLimitLine, tvState, tvRemaining, tvEmpty;
    private ProgressBar barLimit;
    private LinearLayout listCategories, listApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usage);

        tvDate = findViewById(R.id.tvDate);
        tvTotal = findViewById(R.id.tvTotal);
        tvLimitLine = findViewById(R.id.tvLimitLine);
        tvState = findViewById(R.id.tvState);
        tvRemaining = findViewById(R.id.tvRemaining);
        tvEmpty = findViewById(R.id.tvEmpty);
        barLimit = findViewById(R.id.barLimit);
        listCategories = findViewById(R.id.listCategories);
        listApps = findViewById(R.id.listApps);

        setUpChrome(R.id.tabUsage);
        findViewById(R.id.tvBack).setOnClickListener(v -> goTo(MainActivity.class));
        findViewById(R.id.tvPeriodWeek).setOnClickListener(v -> goTo(HistoryActivity.class));
        findViewById(R.id.tvEditLimit).setOnClickListener(v -> goTo(SettingsActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncUsage();
        render(UsagePresenter.present(session.getPet(), session.getTracker(), session.getSettings()));
    }

    private void render(UsageModel m) {
        tvDate.setText(m.getDateLine());
        tvTotal.setText(m.getTotalText());
        tvLimitLine.setText(m.getLimitLine());
        tvRemaining.setText(m.getRemainingText());
        barLimit.setProgress((int) Math.round(m.getLimitFraction() * BAR_MAX));

        tvState.setText(m.getStateName());
        // Only the Healthy color is designed so far; the other states use a placeholder.
        tvState.setTextColor(ContextCompat.getColor(this,
                "Healthy".equals(m.getStateName()) ? R.color.state_text_healthy : R.color.state_text_other));

        listCategories.removeAllViews();
        listApps.removeAllViews();
        tvEmpty.setVisibility(m.isEmpty() ? View.VISIBLE : View.GONE);

        LayoutInflater inflater = LayoutInflater.from(this);
        for (UsageModel.CategoryRow row : m.getCategories()) {
            View item = inflater.inflate(R.layout.item_category_row, listCategories, false);
            ((TextView) item.findViewById(R.id.tvCategoryLabel)).setText(row.getLabel());
            ((TextView) item.findViewById(R.id.tvCategoryMinutes)).setText(row.getMinutesText());
            ProgressBar bar = item.findViewById(R.id.barCategory);
            bar.setProgress((int) Math.round(row.getFraction() * BAR_MAX));
            bar.setProgressTintList(ColorStateList.valueOf(colorFor("bar_", row.getCategoryKey(), R.color.bar_other)));
            listCategories.addView(item);
        }
        for (UsageModel.AppRow row : m.getApps()) {
            View item = inflater.inflate(R.layout.item_app_row, listApps, false);
            ((TextView) item.findViewById(R.id.tvAppName)).setText(row.getAppName());
            ((TextView) item.findViewById(R.id.tvAppCategory)).setText(row.getCategoryLabel());
            ((TextView) item.findViewById(R.id.tvAppMinutes)).setText(row.getMinutesText());
            GradientDrawable marker = (GradientDrawable) item.findViewById(R.id.markerCategory).getBackground().mutate();
            marker.setColor(colorFor("marker_", row.getCategoryKey(), R.color.marker_other));
            listApps.addView(item);
        }
    }

    /** Looks up bar_social, marker_games, ... by name; unknown categories use the fallback. */
    private int colorFor(String prefix, String categoryKey, int fallbackRes) {
        int id = getResources().getIdentifier(prefix + categoryKey, "color", getPackageName());
        return ContextCompat.getColor(this, id != 0 ? id : fallbackRes);
    }
}
