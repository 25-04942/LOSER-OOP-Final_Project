package loser.android;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.TimeUnit;

import loser.exception.MissingPermissionException;

/**
 * Runs about every 15 minutes in the background (Android's minimum for repeating work), even when
 * the app is closed: reads the usage, updates the pet and sends the alerts that are due.
 */
public class UsageCheckWorker extends Worker {
    private static final String WORK_NAME = "loser_usage_check";

    public UsageCheckWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    /** Starts the repeating check once; calling it again keeps the existing one. */
    public static void schedule(Context context) {
        PeriodicWorkRequest request =
                new PeriodicWorkRequest.Builder(UsageCheckWorker.class, 15, TimeUnit.MINUTES).build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            UsageRefresher.run(getApplicationContext());
        } catch (MissingPermissionException e) {
            // usage access not allowed yet: nothing to do until the user allows it
        }
        return Result.success();
    }
}
