package loser.android;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalTime;

import loser.app.AppSession;
import loser.core.Settings;
import loser.core.WeeklyReport;
import loser.exception.InvalidSettingsException;
import loser.notification.UsageMonitor;
import loser.storage.RecordCodec;

/**
 * Keeps everything that must survive closing the app, on the device only (SharedPreferences):
 * the settings, the pet's name, the daily records of the week and which alerts were already sent.
 */
public class AppStore {
    private static final String FILE = "loser_store";
    private static final String KEY_LIMIT = "daily_limit";
    private static final String KEY_RESET_MINUTES = "reset_minutes";
    private static final String KEY_PET_UPDATES = "pet_updates_on";
    private static final String KEY_WARNINGS = "warnings_on";
    private static final String KEY_LONG_SESSION = "long_session";
    private static final String KEY_TIRED = "level_tired";
    private static final String KEY_SICK = "level_sick";
    private static final String KEY_DEVASTATED = "level_devastated";
    private static final String KEY_PET_NAME = "pet_name";
    private static final String KEY_SETUP_DONE = "setup_done";
    private static final String KEY_DAYS = "days";
    private static final String KEY_MONITOR = "monitor";

    private final SharedPreferences prefs;

    public AppStore(Context context) {
        prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Copies everything saved into the session. Anything missing or invalid keeps its default. */
    public void load(AppSession session) {
        Settings s = session.getSettings();
        try {
            s.setDailyLimit(prefs.getInt(KEY_LIMIT, s.getDailyLimit()));
            s.setLongSessionMinutes(prefs.getInt(KEY_LONG_SESSION, s.getLongSessionMinutes()));
            s.setThresholds(prefs.getInt(KEY_TIRED, s.getTiredPercent()),
                    prefs.getInt(KEY_SICK, s.getSickPercent()),
                    prefs.getInt(KEY_DEVASTATED, s.getDevastatedPercent()));
            int minutes = prefs.getInt(KEY_RESET_MINUTES, s.getResetTime().toSecondOfDay() / 60);
            s.setResetTime(LocalTime.of(minutes / 60, minutes % 60));
        } catch (InvalidSettingsException | RuntimeException e) {
            // a saved value is not allowed (any more): the rest of the defaults stay
        }
        s.setNotificationsOn(prefs.getBoolean(KEY_PET_UPDATES, s.isNotificationsOn()));
        s.setWarningsOn(prefs.getBoolean(KEY_WARNINGS, s.isWarningsOn()));
        try {
            session.getPet().setName(prefs.getString(KEY_PET_NAME, session.getPet().getName()));
        } catch (IllegalArgumentException e) {
            // keep the default name
        }
        session.restoreDays(RecordCodec.decodeAll(prefs.getString(KEY_DAYS, "")));
        session.getMonitor().restoreState(prefs.getString(KEY_MONITOR, ""));
    }

    /** Saves the settings and the pet's name. */
    public void saveSettings(AppSession session) {
        Settings s = session.getSettings();
        prefs.edit()
                .putInt(KEY_LIMIT, s.getDailyLimit())
                .putInt(KEY_RESET_MINUTES, s.getResetTime().toSecondOfDay() / 60)
                .putBoolean(KEY_PET_UPDATES, s.isNotificationsOn())
                .putBoolean(KEY_WARNINGS, s.isWarningsOn())
                .putInt(KEY_LONG_SESSION, s.getLongSessionMinutes())
                .putInt(KEY_TIRED, s.getTiredPercent())
                .putInt(KEY_SICK, s.getSickPercent())
                .putInt(KEY_DEVASTATED, s.getDevastatedPercent())
                .putString(KEY_PET_NAME, session.getPet().getName())
                .apply();
    }

    /** Saves the last 7 daily records. */
    public void saveDays(WeeklyReport report) {
        prefs.edit().putString(KEY_DAYS, RecordCodec.encodeAll(report.getDays())).apply();
    }

    /** Saves which alerts were sent today, so they are not sent twice after the app restarts. */
    public void saveMonitor(UsageMonitor monitor) {
        prefs.edit().putString(KEY_MONITOR, monitor.saveState()).apply();
    }

    public boolean isSetupDone() {
        return prefs.getBoolean(KEY_SETUP_DONE, false);
    }

    public void setSetupDone(boolean done) {
        prefs.edit().putBoolean(KEY_SETUP_DONE, done).apply();
    }
}
