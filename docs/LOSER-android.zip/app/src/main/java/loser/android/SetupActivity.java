package loser.android;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.time.LocalTime;

import loser.exception.InvalidSettingsException;
import loser.ui.DashboardPresenter;
import loser.ui.SettingsForm;
import loser.ui.SettingsPresenter;

/**
 * First-run setup (proposal, Phase 1): create the pet, set the daily limit and the reset time.
 * The values are checked and saved by SettingsPresenter.applyAll (plain Java, unit tested).
 * The next step is the Connect screen, where the two permissions are requested.
 */
public class SetupActivity extends BaseScreenActivity {
    private EditText etPetName, etHours, etMinutes;
    private TextView tvResetTime, tvLimitHint, tvFormError;
    private LocalTime resetTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        setUpChrome(0);   // no bottom navigation on this screen

        etPetName = findViewById(R.id.etPetName);
        etHours = findViewById(R.id.etHours);
        etMinutes = findViewById(R.id.etMinutes);
        tvResetTime = findViewById(R.id.tvResetTime);
        tvLimitHint = findViewById(R.id.tvLimitHint);
        tvFormError = findViewById(R.id.tvFormError);

        // start from the defaults (or from whatever was saved if the user left half-way)
        SettingsForm form = SettingsForm.current(session.getSettings(), session.getPet());
        etPetName.setText(form.getPetName());
        etHours.setText(form.getHours());
        etMinutes.setText(form.getMinutes());
        resetTime = form.getResetTime();
        showResetTime();
        tvLimitHint.setText(SettingsPresenter.limitHint());

        tvResetTime.setOnClickListener(v -> pickTime(resetTime, time -> {
            resetTime = time;
            showResetTime();
        }));
        findViewById(R.id.btnContinue).setOnClickListener(v -> save());
        etMinutes.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                save();
                return true;
            }
            return false;
        });
    }

    private void showResetTime() {
        tvResetTime.setText(DashboardPresenter.clockText(resetTime));
    }

    private void save() {
        SettingsForm form = SettingsForm.current(session.getSettings(), session.getPet())
                .withPetName(etPetName.getText().toString())
                .withLimit(etHours.getText().toString(), etMinutes.getText().toString())
                .withResetTime(resetTime);
        try {
            SettingsPresenter.applyAll(session.getSettings(), session.getPet(), form);
        } catch (InvalidSettingsException e) {
            tvFormError.setText(e.getMessage());
            tvFormError.setVisibility(View.VISIBLE);
            return;
        }
        tvFormError.setVisibility(View.GONE);

        LoserApp app = (LoserApp) getApplication();
        app.getStore().saveSettings(session);
        app.getStore().setSetupDone(true);
        session.rollOverIfNewDay(session.logicalDay(java.time.LocalDateTime.now()));   // the new reset time may move "today"

        Intent next = new Intent(this, ConnectActivity.class).putExtra(ConnectActivity.EXTRA_SETUP, true);
        startActivity(next);
        finish();
    }
}
