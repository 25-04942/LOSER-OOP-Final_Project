package loser.android

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import loser.exception.MissingPermissionException
import loser.model.UsageRecord
import loser.source.UsageSource
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * Reads the per-app usage of one day from Android and returns it as Java UsageRecord objects.
 * Implements the Java interface UsageSource, so the rest of the app does not care
 * whether data comes from the phone or from SampleUsageSource.
 */
class UsageReader(private val context: Context) : UsageSource {

    private val permissionHelper = PermissionHelper(context)

    /**
     * One "day" starts at the user's reset time and lasts 24 hours. The current day is read up
     * to now; a past day up to the next reset time.
     */
    @Throws(MissingPermissionException::class)
    override fun readUsageFor(day: LocalDate, resetTime: LocalTime): List<UsageRecord> {
        permissionHelper.requireAccess()

        val zone = ZoneId.systemDefault()
        val start = day.atTime(resetTime).atZone(zone).toInstant().toEpochMilli()
        val dayEnd = day.plusDays(1).atTime(resetTime).atZone(zone).toInstant().toEpochMilli()
        val now = System.currentTimeMillis()
        val end = if (dayEnd < now) dayEnd else now
        if (start >= end) return emptyList()      // this day has not started yet

        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(start, end)
        val event = UsageEvents.Event()

        val openSince = HashMap<String, Long>()   // package -> when it came to foreground
        val totalMs = HashMap<String, Long>()
        val longestMs = HashMap<String, Long>()

        fun closeSession(pkg: String, end: Long) {
            val begin = openSince.remove(pkg) ?: return
            val length = end - begin
            if (length <= 0) return
            totalMs[pkg] = (totalMs[pkg] ?: 0L) + length
            if (length > (longestMs[pkg] ?: 0L)) longestMs[pkg] = length
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val pkg = event.packageName ?: continue
            @Suppress("DEPRECATION")
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> openSince[pkg] = event.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> closeSession(pkg, event.timeStamp)
            }
        }
        // apps still open at the end of the period (right now, or at midnight)
        for (pkg in openSince.keys.toList()) closeSession(pkg, end)

        val pm = context.packageManager
        val records = ArrayList<UsageRecord>()
        for ((pkg, ms) in totalMs) {
            if (pkg == context.packageName) continue          // ignore LOS:ER itself
            val minutes = (ms / 60_000L).toInt()
            if (minutes <= 0) continue
            // floor both values so longest can never exceed total
            val longest = ((longestMs[pkg] ?: 0L) / 60_000L).toInt().coerceAtMost(minutes)
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: PackageManager.NameNotFoundException) {
                pkg
            }
            records.add(UsageRecord(label, AppCategorizer.categorize(pkg), minutes, longest, day))
        }
        return records.sortedByDescending { it.minutesUsed }
    }
}
