package loser.android;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import loser.core.Settings;
import loser.notification.NotificationService;

/**
 * The Android version of NotificationService (inheritance + polymorphism): the rules about WHEN
 * to notify stay in the Java core; only deliver() changes, to show a real notification.
 */
public class AndroidNotificationService extends NotificationService {
    public static final String CHANNEL_ID = "loser_alerts";

    private final Context context;

    public AndroidNotificationService(Context context, Settings settings) {
        super(settings);
        this.context = context.getApplicationContext();
    }

    /** Call once when the app starts (Android 8+ needs a channel before showing notifications). */
    public static void createChannel(Context context) {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                context.getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription(context.getString(R.string.channel_description));
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }

    @SuppressLint("MissingPermission")   // checked with areNotificationsEnabled() below
    @Override
    protected void deliver(String message) {
        NotificationManagerCompat manager = NotificationManagerCompat.from(context);
        if (!manager.areNotificationsEnabled()) {
            return;   // the user turned notifications off in Android
        }
        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_nav_pet)
                .setContentTitle(context.getString(R.string.app_name))
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .build();
        manager.notify((int) (System.currentTimeMillis() % Integer.MAX_VALUE), notification);
    }
}
