package loser.android

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import loser.exception.MissingPermissionException

/** Checks and requests the "Usage access" special permission. */
class PermissionHelper(private val context: Context) {

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = checkMode(appOps)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun checkMode(appOps: AppOpsManager): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }

    /** Opens the system screen where the user turns Usage access on for this app. */
    fun openUsageAccessSettings() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** Throws MissingPermissionException (defined in the Java core) if access is not granted. */
    @Throws(MissingPermissionException::class)
    fun requireAccess() {
        if (!hasUsageAccess()) throw MissingPermissionException()
    }
}
