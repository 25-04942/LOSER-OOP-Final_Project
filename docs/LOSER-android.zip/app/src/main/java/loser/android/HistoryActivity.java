package loser.android;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import loser.ui.HistoryModel;
import loser.ui.HistoryPresenter;

/**
 * "Weekly history" screen. HistoryPresenter (plain Java, unit tested) prepares every text and
 * bar height; this class reads the past days from the phone and fills the views.
 */
public class HistoryActivity extends BaseScreenActivity {
    /** Height of the chart's plot area in the design; the tallest value fills it. */
    private static final int PLOT_HEIGHT_DP = 108;
    /** Distance from the top of the chart card to the bottom of the bars. */
    private static final int PLOT_BOTTOM_DP = 190;
    private static final int MIN_BAR_DP = 2;       // a day with no usage still shows a small stub

    private TextView tvRange, tvAverage, tvAverageChange, tvHighest, tvHighestDate;
    private TextView tvLimitText, tvInsightTitle, tvInsightBody, tvEmpty;
    private View viewLimitGuide, cardInsight;
    private LinearLayout chartColumns, listRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        tvRange = findViewById(R.id.tvRange);
        tvAverage = findViewById(R.id.tvAverage);
        tvAverageChange = findViewById(R.id.tvAverageChange);
        tvHighest = findViewById(R.id.tvHighest);
        tvHighestDate = findViewById(R.id.tvHighestDate);
        tvLimitText = findViewById(R.id.tvLimitText);
        tvInsightTitle = findViewById(R.id.tvInsightTitle);
        tvInsightBody = findViewById(R.id.tvInsightBody);
        tvEmpty = findViewById(R.id.tvEmpty);
        viewLimitGuide = findViewById(R.id.viewLimitGuide);
        cardInsight = findViewById(R.id.cardInsight);
        chartColumns = findViewById(R.id.chartColumns);
        listRecords = findViewById(R.id.listRecords);

        setUpChrome(R.id.tabHistory);
        findViewById(R.id.tvBack).setOnClickListener(v -> goTo(UsageActivity.class));
        findViewById(R.id.tvPeriodToday).setOnClickListener(v -> goTo(UsageActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncUsage();   // if the permission is missing the saved days stay as they were
        render(HistoryPresenter.present(session.getWeeklyReport(), session.getSettings()));
    }

    private void render(HistoryModel m) {
        tvRange.setText(m.getRangeLine());
        tvAverage.setText(m.getAverageText());
        tvAverageChange.setText(m.getAverageChangeText());
        tvAverageChange.setTextColor(ContextCompat.getColor(this, toneColor(m.getAverageChangeTone())));
        tvHighest.setText(m.getHighestText());
        tvHighestDate.setText(m.getHighestDateText());
        tvLimitText.setText(m.getLimitText());
        tvEmpty.setVisibility(m.isEmpty() ? View.VISIBLE : View.GONE);

        // limit guide: PLOT_BOTTOM_DP is the baseline, the plot is PLOT_HEIGHT_DP tall
        FrameLayout.LayoutParams guide = (FrameLayout.LayoutParams) viewLimitGuide.getLayoutParams();
        guide.topMargin = dp(PLOT_BOTTOM_DP - m.getLimitFraction() * PLOT_HEIGHT_DP);
        viewLimitGuide.setLayoutParams(guide);

        // insight card: green for a balanced week, lavender (placeholder) for a busy one
        int textColor = ContextCompat.getColor(this, m.isInsightGood() ? R.color.success_text : R.color.text_primary);
        ((GradientDrawable) cardInsight.getBackground().mutate()).setColor(
                ContextCompat.getColor(this, m.isInsightGood() ? R.color.card_healthy : R.color.card_tired));
        tvInsightTitle.setText(m.getInsightTitle());
        tvInsightBody.setText(m.getInsightBody());
        tvInsightTitle.setTextColor(textColor);
        tvInsightBody.setTextColor(textColor);

        LayoutInflater inflater = LayoutInflater.from(this);

        chartColumns.removeAllViews();
        for (HistoryModel.Bar bar : m.getBars()) {
            View column = inflater.inflate(R.layout.item_chart_day, chartColumns, false);
            ((TextView) column.findViewById(R.id.tvDayLetter)).setText(bar.getLetter());
            ((TextView) column.findViewById(R.id.tvDayNumber)).setText(bar.getDateNumber());
            column.setContentDescription(bar.getDescription());

            View viewBar = column.findViewById(R.id.viewBar);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) viewBar.getLayoutParams();
            lp.height = Math.max(dp(MIN_BAR_DP), dp(bar.getFraction() * PLOT_HEIGHT_DP));
            viewBar.setLayoutParams(lp);
            ((GradientDrawable) viewBar.getBackground().mutate()).setColor(
                    ContextCompat.getColor(this, bar.isOverLimit() ? R.color.bar_over : R.color.accent));
            chartColumns.addView(column);
        }

        listRecords.removeAllViews();
        for (HistoryModel.Record record : m.getRecords()) {
            View row = inflater.inflate(R.layout.item_record_row, listRecords, false);
            ((TextView) row.findViewById(R.id.tvRecordDate)).setText(record.getDateText());
            ((TextView) row.findViewById(R.id.tvRecordTotal)).setText(record.getTotalText());
            TextView status = row.findViewById(R.id.tvRecordStatus);
            status.setText(record.getStatusText());
            status.setTextColor(ContextCompat.getColor(this,
                    record.isWithinLimit() ? R.color.success_text : R.color.warn_text));
            row.setOnClickListener(v ->
                    Toast.makeText(this, R.string.history_day_soon, Toast.LENGTH_SHORT).show());
            listRecords.addView(row);
        }
    }

    private int toneColor(HistoryModel.Tone tone) {
        switch (tone) {
            case GOOD: return R.color.success_text;
            case WARN: return R.color.warn_text;
            default:   return R.color.text_secondary;
        }
    }

    private int dp(double value) {
        return (int) Math.round(value * getResources().getDisplayMetrics().density);
    }
}
