package loser.android;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import loser.ui.ConnectModel;
import loser.ui.ConnectPresenter;

/**
 * "Connect your device" screen: step 1 usage access (required), step 2 notifications (optional).
 * ConnectPresenter (plain Java, unit tested) decides the texts; this class checks the two
 * Android permissions and styles the buttons.
 */
public class ConnectActivity extends BaseScreenActivity {
    public static final String EXTRA_SETUP = "loser.extra.SETUP";
    private static final int REQUEST_NOTIFICATIONS = 1;

    private boolean setupMode;   // true when opened as the last step of the first-run setup

    private TextView tvUsageStatus, tvNotificationStatus, tvContinueHint;
    private TextView btnUsageAccess, btnNotifications, btnContinue;
    private TextView tvUsageFootnote, tvConnectSubtitle, tvUsageBody;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect);

        tvUsageStatus = findViewById(R.id.tvUsageStatus);
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus);
        tvContinueHint = findViewById(R.id.tvContinueHint);
        tvUsageFootnote = findViewById(R.id.tvUsageFootnote);
        btnUsageAccess = findViewById(R.id.btnUsageAccess);
        btnNotifications = findViewById(R.id.btnNotifications);
        btnContinue = findViewById(R.id.btnContinue);

        tvConnectSubtitle = findViewById(R.id.tvConnectSubtitle);
        tvUsageBody = findViewById(R.id.tvUsageBody);

        setupMode = getIntent().getBooleanExtra(EXTRA_SETUP, false);
        if (setupMode) {
            // first-run: no navigation and no way back to Settings
            findViewById(R.id.bottomNav).setVisibility(View.GONE);
            findViewById(R.id.tvBack).setVisibility(View.INVISIBLE);
        }
        setUpChrome(R.id.tabSettings);   // reached from Settings, so the Settings tab stays highlighted

        findViewById(R.id.tvBack).setOnClickListener(v -> goTo(SettingsActivity.class));
        btnUsageAccess.setOnClickListener(v -> openUsageAccessSettings());
        btnNotifications.setOnClickListener(v -> askForNotifications());
        btnContinue.setOnClickListener(v -> {
            if (!btnContinue.isEnabled()) return;
            if (setupMode) {
                Intent home = new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(home);
            } else {
                goTo(MainActivity.class);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();   // also runs when the user comes back from the Android settings
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            refresh();
            if (!areNotificationsAllowed()) {
                openNotificationSettings();   // the system will not ask again, so send the user there
            }
        }
    }

    private boolean areNotificationsAllowed() {
        return NotificationManagerCompat.from(this).areNotificationsEnabled();
    }

    private void refresh() {
        ConnectModel m = ConnectPresenter.present(hasUsageAccess(), areNotificationsAllowed(), petName());

        tvConnectSubtitle.setText(m.getSubtitle());
        tvUsageBody.setText(m.getUsageBody());
        tvUsageFootnote.setText(m.getUsageFootnote());

        // step 1
        tvUsageStatus.setText(m.getUsageStatus());
        tvUsageStatus.setTextColor(ContextCompat.getColor(this, m.isUsageAllowed() ? R.color.success_text : R.color.accent));
        btnUsageAccess.setText(m.getUsageButton());
        btnUsageAccess.setEnabled(!m.isUsageAllowed());
        btnUsageAccess.setBackgroundResource(m.isUsageAllowed() ? R.drawable.bg_button_done : R.drawable.bg_button_cta);
        btnUsageAccess.setTextColor(ContextCompat.getColor(this, m.isUsageAllowed() ? R.color.accent : R.color.white));
        tvUsageFootnote.setVisibility(m.isUsageFootnoteVisible() ? View.VISIBLE : View.INVISIBLE);

        // step 2
        tvNotificationStatus.setText(m.getNotificationStatus());
        tvNotificationStatus.setTextColor(ContextCompat.getColor(this,
                m.isNotificationsAllowed() ? R.color.success_text : R.color.text_secondary));
        btnNotifications.setText(m.getNotificationButton());
        btnNotifications.setEnabled(!m.isNotificationsAllowed());

        // continue: unavailable (as designed) until usage access is allowed.
        // The available look is not in the design: it reuses the purple "Save preferences" button.
        btnContinue.setEnabled(m.canContinue());
        btnContinue.setBackgroundResource(m.canContinue() ? R.drawable.bg_button : R.drawable.bg_button_disabled);
        btnContinue.setTextColor(ContextCompat.getColor(this,
                m.canContinue() ? R.color.white : R.color.button_disabled_text));
        tvContinueHint.setText(m.getContinueHint());
        tvContinueHint.setVisibility(m.canContinue() ? View.INVISIBLE : View.VISIBLE);
    }

    private void askForNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        } else {
            openNotificationSettings();   // before Android 13 there is no pop-up, only the settings page
        }
    }

    private void openNotificationSettings() {
        Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(intent);
    }
}
