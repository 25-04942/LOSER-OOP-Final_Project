package loser.android

import loser.model.Category

/** Maps Android package names to LOS:ER categories. Add more apps to the map as needed. */
object AppCategorizer {

    private val known: Map<String, Category> = mapOf(
        // Social
        "com.facebook.katana" to Category.SOCIAL,
        "com.instagram.android" to Category.SOCIAL,
        "com.zhiliaoapp.musically" to Category.SOCIAL,      // TikTok
        "com.twitter.android" to Category.SOCIAL,
        "com.snapchat.android" to Category.SOCIAL,
        "com.reddit.frontpage" to Category.SOCIAL,
        // Games
        "com.mobile.legends" to Category.GAMES,
        "com.tencent.ig" to Category.GAMES,                  // PUBG Mobile
        "com.supercell.clashofclans" to Category.GAMES,
        "com.roblox.client" to Category.GAMES,
        "com.mojang.minecraftpe" to Category.GAMES,
        "com.miHoYo.GenshinImpact" to Category.GAMES,
        // Study
        "com.google.android.apps.classroom" to Category.STUDY,
        "com.duolingo" to Category.STUDY,
        "org.khanacademy.android" to Category.STUDY,
        "com.google.android.apps.docs" to Category.STUDY,
        "com.microsoft.office.word" to Category.STUDY,
        // Communication
        "com.facebook.orca" to Category.COMMUNICATION,      // Messenger
        "com.whatsapp" to Category.COMMUNICATION,
        "org.telegram.messenger" to Category.COMMUNICATION,
        "com.viber.voip" to Category.COMMUNICATION,
        "com.discord" to Category.COMMUNICATION,
        "com.google.android.gm" to Category.COMMUNICATION,  // Gmail
        "us.zoom.videomeetings" to Category.COMMUNICATION,
        "com.microsoft.teams" to Category.COMMUNICATION
    )

    fun categorize(packageName: String): Category {
        known[packageName]?.let { return it }
        val lower = packageName.lowercase()
        return when {
            "game" in lower -> Category.GAMES
            "messenger" in lower || "chat" in lower || "mail" in lower -> Category.COMMUNICATION
            else -> Category.OTHER
        }
    }
}
