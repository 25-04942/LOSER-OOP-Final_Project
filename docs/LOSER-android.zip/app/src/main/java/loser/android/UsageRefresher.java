package loser.android;

import android.content.Context;

import java.time.LocalDate;
import java.time.LocalDateTime;

import loser.app.AppSession;
import loser.exception.MissingPermissionException;

/**
 * One "update everything" step shared by the screens and the background check:
 * read today's usage, fill in any missing past days, send the alerts that are due,
 * and remember which alerts were sent.
 */
final class UsageRefresher {
    private UsageRefresher() { }

    static void run(Context context) throws MissingPermissionException {
        LoserApp app = (LoserApp) context.getApplicationContext();
        AppSession session = app.getSession();
        UsageReader reader = new UsageReader(context);
        LocalDate day = session.logicalDay(LocalDateTime.now());   // follows the user's reset time
        try {
            session.sync(reader, day);
            session.loadHistory(reader, day);
        } finally {
            app.getStore().saveMonitor(session.getMonitor());
        }
    }
}
