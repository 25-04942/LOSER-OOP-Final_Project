package loser.android;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import loser.ui.DashboardModel;
import loser.ui.DashboardPresenter;

/**
 * Pet dashboard screen. All text comes from DashboardPresenter (plain Java, unit tested);
 * this class only reads the phone's usage and puts the result into the views.
 */
public class MainActivity extends BaseScreenActivity {
    private TextView tvPetName, tvCondition, tvSpeech, tvTotal, tvLimitLine;
    private TextView tvConditionTitle, tvConditionBody, tvResetLine;
    private ImageView ivPet, ivBackdrop, ivCondition;
    private View petRoom, cardScreenTime, cardCondition;
    private ObjectAnimator idleAnimation;      // the pet's gentle up-and-down movement
    private String animatedState = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!((LoserApp) getApplication()).getStore().isSetupDone()) {
            // first launch: create the pet and choose the limit and reset time first
            startActivity(new Intent(this, SetupActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);

        bindViews();
        setUpChrome(R.id.tabPet);
        findViewById(R.id.tvLimitsLink).setOnClickListener(v -> goTo(SettingsActivity.class));
        findViewById(R.id.tvViewUsage).setOnClickListener(v -> goTo(UsageActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isFinishing()) return;   // went to the setup screen instead
        refresh();   // also runs when the user comes back from the Usage access screen
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopIdleAnimation();   // no animation while the screen is not visible
    }

    private void bindViews() {
        tvPetName = findViewById(R.id.tvPetName);
        tvCondition = findViewById(R.id.tvCondition);
        tvSpeech = findViewById(R.id.tvSpeech);
        tvTotal = findViewById(R.id.tvTotal);
        tvLimitLine = findViewById(R.id.tvLimitLine);
        tvConditionTitle = findViewById(R.id.tvConditionTitle);
        tvConditionBody = findViewById(R.id.tvConditionBody);
        tvResetLine = findViewById(R.id.tvResetLine);
        ivPet = findViewById(R.id.ivPet);
        ivBackdrop = findViewById(R.id.ivBackdrop);
        ivCondition = findViewById(R.id.ivCondition);
        petRoom = findViewById(R.id.petRoom);
        cardScreenTime = findViewById(R.id.cardScreenTime);
        cardCondition = findViewById(R.id.cardCondition);
    }

    // ---------- data ----------
    private void refresh() {
        boolean permissionMissing = syncUsage();

        render(DashboardPresenter.present(session.getPet(), session.getTracker(), session.getSettings()));

        if (permissionMissing) {
            tvConditionTitle.setText(R.string.permission_needed_title);
            tvConditionBody.setText(getString(R.string.permission_needed_body, session.getPet().getName()));
        }
    }

    // ---------- drawing ----------
    private void render(DashboardModel m) {
        tvPetName.setText(m.getPetName());
        tvCondition.setText(m.getStateName());
        tvSpeech.setText(m.getSpeech());
        tvTotal.setText(m.getTotalText());
        tvLimitLine.setText(m.getLimitLine());
        tvConditionTitle.setText(m.getConditionTitle());
        tvConditionBody.setText(m.getConditionBody());
        tvResetLine.setText(m.getResetLine());

        // Pictures are looked up by name (pet_tired, room_backdrop_tired, ic_condition_tired...).
        // A state whose pictures are not exported yet falls back to the Healthy ones.
        setImageByName(ivPet, m.getSpriteName(), R.drawable.pet_healthy);
        setImageByName(ivBackdrop, m.getBackdropName(), R.drawable.room_backdrop_healthy);
        setImageByName(ivCondition, m.getIndicatorName(), R.drawable.ic_condition_healthy);
        ivPet.setContentDescription(getString(R.string.pet_content_description,
                m.getPetName(), m.getStateName()));

        startIdleAnimation(m.getStateName());

        // Room and both cards change color with the state.
        tint(petRoom, roomColor(m.getStateName()));
        tint(cardScreenTime, cardColor(m.getStateName()));
        tint(cardCondition, cardColor(m.getStateName()));
    }

    /**
     * Basic animation (proposal): the pet floats gently. A healthy pet moves more and faster,
     * a sick or devastated one barely moves. Skipped when the user turned animations off.
     */
    private void startIdleAnimation(String stateName) {
        if (idleAnimation != null && idleAnimation.isStarted() && stateName.equals(animatedState)) {
            return;   // already running for this state
        }
        stopIdleAnimation();
        if (!ValueAnimator.areAnimatorsEnabled()) {
            return;
        }
        float density = getResources().getDisplayMetrics().density;
        float distanceDp;
        long durationMs;
        switch (stateName) {
            case "Tired":      distanceDp = 4; durationMs = 2400; break;
            case "Sick":       distanceDp = 3; durationMs = 900;  break;   // small, shaky
            case "Devastated": distanceDp = 2; durationMs = 3000; break;
            default:           distanceDp = 6; durationMs = 1400; break;
        }
        idleAnimation = ObjectAnimator.ofFloat(ivPet, View.TRANSLATION_Y, 0f, -distanceDp * density);
        idleAnimation.setDuration(durationMs);
        idleAnimation.setRepeatCount(ValueAnimator.INFINITE);
        idleAnimation.setRepeatMode(ValueAnimator.REVERSE);
        idleAnimation.setInterpolator(new AccelerateDecelerateInterpolator());
        idleAnimation.start();
        animatedState = stateName;
    }

    private void stopIdleAnimation() {
        if (idleAnimation != null) {
            idleAnimation.cancel();
            idleAnimation = null;
        }
        if (ivPet != null) ivPet.setTranslationY(0f);
        animatedState = "";
    }

    private void setImageByName(ImageView view, String drawableName, int fallbackRes) {
        int id = getResources().getIdentifier(drawableName, "drawable", getPackageName());
        view.setImageResource(id != 0 ? id : fallbackRes);
    }

    /** The backgrounds are rounded-rectangle shapes, so changing their color keeps the corners. */
    private void tint(View view, int colorRes) {
        GradientDrawable bg = (GradientDrawable) view.getBackground().mutate();
        bg.setColor(ContextCompat.getColor(this, colorRes));
    }

    private int roomColor(String stateName) {
        switch (stateName) {
            case "Tired":      return R.color.room_tired;
            case "Sick":       return R.color.room_sick;
            case "Devastated": return R.color.room_devastated;
            default:           return R.color.room_healthy;
        }
    }

    private int cardColor(String stateName) {
        switch (stateName) {
            case "Tired":      return R.color.card_tired;
            case "Sick":       return R.color.card_sick;
            case "Devastated": return R.color.card_devastated;
            default:           return R.color.card_healthy;
        }
    }
}
